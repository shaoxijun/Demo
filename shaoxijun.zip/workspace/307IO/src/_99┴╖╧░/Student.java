package _99��ϰ;

public class Student
{
	
		String id;
		String name;
		int chinese;
		int math;
		int english;
		@Override
		public String toString()
		{
			return  id + ", " + name + ", " + chinese + ", " + math + ", "
					+ english;
		}
		
	
}
