package ����02;


public class Test
{
	public static void main(String[] args)
	{
		Poker p5 = new Poker();
		p5.deal();
	}
}
