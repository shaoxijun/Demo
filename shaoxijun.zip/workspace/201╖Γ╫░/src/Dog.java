
public class Dog
{
	
	String name;
	int age;
	void bone()
	{
		System.out.println(name+"��й�ͷ");
	}
	
	void lookhome()
	{
		System.out.println(name+"�ῴ��");
	}
	
	void sleep()
	{
		System.out.println(name+"��˯��");
	}

}
