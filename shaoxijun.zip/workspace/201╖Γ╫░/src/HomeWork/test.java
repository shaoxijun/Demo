package HomeWork;

public class test
{
	 public static void main(String[] args)
	{
		 NumberList l = new NumberList();
		 l.print();
		 l.add(3);
		 l.print();
		 l.add(4,4,3,1,4);
		 l.print();
	}
	 
}
