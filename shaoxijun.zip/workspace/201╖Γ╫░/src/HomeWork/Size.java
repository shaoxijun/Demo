package HomeWork;

public class Size
{
	private int weigth;
	private int heigth;
	public int getWeigth()
	{
		return weigth;
	}
	public void setWeigth(int weigth)
	{
		this.weigth = weigth;
	}
	public int getHeigth()
	{
		return heigth;
	}
	public void setHeigth(int heigth)
	{
		this.heigth = heigth;
	}
	public Size(int weigth, int heigth)
	{
		super();
		this.weigth = weigth;
		this.heigth = heigth;
	}
	public Size()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
}
