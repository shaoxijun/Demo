package _1ö������;

public class Demo
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Light l1 = Light.GREEN;
		System.out.println(l1.getName());
		System.out.println(l1.name());
	}

}
