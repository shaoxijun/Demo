package _99��ϰ;

public class E1
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
