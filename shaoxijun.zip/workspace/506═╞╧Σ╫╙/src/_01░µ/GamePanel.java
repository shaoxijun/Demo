package _01��;

public class GamePanel
{

}
