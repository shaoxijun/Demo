package _01��;

public class GameObject
{

}
