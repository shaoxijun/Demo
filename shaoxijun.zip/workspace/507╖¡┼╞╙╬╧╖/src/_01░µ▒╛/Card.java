package _01�汾;

public class Card
{
	String c;
	public Card(String c)
	{
		super();
		this.c = c;
	}
	
}
