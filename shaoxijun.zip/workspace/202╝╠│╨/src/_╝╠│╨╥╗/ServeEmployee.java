package _�̳�һ;

public class ServeEmployee
{
	String name;
	String birthday;
	String date;
	
	
}
