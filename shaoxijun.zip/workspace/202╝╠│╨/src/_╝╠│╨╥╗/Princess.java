package _�̳�һ;

public class Princess extends PlayRole
{

	public Princess(String name, int x, int y)
	{
		super(name, x, y);
		// TODO Auto-generated constructor stub
	}
	String shoes;
	void type()
	{
		System.out.println(name+" ����"+this.x+"  "+this.y+"  "+this.shoes);
	}
}
