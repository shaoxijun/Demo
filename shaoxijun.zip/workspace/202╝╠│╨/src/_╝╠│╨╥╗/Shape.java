package _�̳�һ;

public abstract class Shape
{
	int l;
	int k;
	public Shape()
	{}
	public Shape(int l, int k)
	{
		super();
		this.l = l;
		this.k = k;
	}
	
	abstract void area();
	abstract void round();
	
		
	
}
