package _�̳�һ;

public class Person
{
	String name;
	int age;
	
	
	public Person(String name, int age)
	{
		super();
		this.name = name;
		this.age = age;
	}

	void sleep()
	{
		System.out.println(name+"��˯��");
	}
	void eat()
	{
		System.out.println(name+"�ڳԷ�");
	}
}
