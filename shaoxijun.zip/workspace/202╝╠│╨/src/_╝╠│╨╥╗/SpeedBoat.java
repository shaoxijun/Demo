package _�̳�һ;

public class SpeedBoat extends Boat
{

	public SpeedBoat(String name, int maxSpeed, int people)
	{
		super(name, 50, people);
		// TODO Auto-generated constructor stub
	}
	
}
