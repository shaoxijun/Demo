package _�̳�һ;

public class Boss extends PlayRole
{

	public Boss(String name, int x, int y)
	{
		super(name, x, y);
		// TODO Auto-generated constructor stub
	}
	String car;
	
	void type()
	{
		System.out.println(name+"    ����"+this.x+"  "+this.y+"  "+this.car);
	}
}
