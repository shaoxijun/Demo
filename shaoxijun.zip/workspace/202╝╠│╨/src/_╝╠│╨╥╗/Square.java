package _�̳�һ;

public class Square extends Shape
{

	public Square(int l, int k)
	{
		super(l, k);
	
	}
	public Square(int l)
	{
		this(l,l);
	}
	public Square()
	{}
	@Override
	void area()
	{
		// TODO Auto-generated method stub
		int s = l * k;
		System.out.println(s);
	}

	@Override
	void round()
	{
		// TODO Auto-generated method stub
		int c = l*4;
		System.out.println(c);
	}
	
}
