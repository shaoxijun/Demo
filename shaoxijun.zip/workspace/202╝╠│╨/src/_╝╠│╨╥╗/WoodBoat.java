package _�̳�һ;

public class WoodBoat extends Boat
{

	public WoodBoat(String name, int maxSpeed, int people)
	{
		super(name, 10, people);
		// TODO Auto-generated constructor stub
	}
//	public WoodBoat(int maxSpeed)
//	{
//		;
//	}
	
	
}