package _�̳�һ;

public class WarShip extends Boat
{

	String attack;
	public WarShip(String name, int maxSpeed, int people)
	{
		super(name, 100, people);
		// TODO Auto-generated constructor stub
	}

}
