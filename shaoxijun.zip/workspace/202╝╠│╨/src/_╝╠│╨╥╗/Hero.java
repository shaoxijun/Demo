package _�̳�һ;

public class Hero extends PlayRole
{

	public Hero(String name, int x, int y)
	{
		super(name, x, y);
		// TODO Auto-generated constructor stub
	}
	String gun;
	void type()
	{
		System.out.println(name+" ����"+this.x+"  "+this.y+"  "+this.gun);
	}
}
