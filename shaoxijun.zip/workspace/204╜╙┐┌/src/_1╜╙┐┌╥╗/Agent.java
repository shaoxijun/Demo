package _1�ӿ�һ;

public class Agent implements IFindRoomAble
{
	@Override
	public int findroom()
	{
	
			int a =((int)(22*Math.random()))*100+800;
			return a;
	}
	String name;
	private int price;
	

	
	
}
