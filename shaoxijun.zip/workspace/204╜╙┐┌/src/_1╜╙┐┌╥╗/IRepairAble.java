package _1�ӿ�һ;

public interface IRepairAble
{
	void repair();
}
