package _1�ӿ�һ;

public interface IBoyfriendAble
{
	void goStreet();
	void watchFilm();
	void cook();
	
}
