package _1�ӿ�һ;

public interface IFindRoomAble
{
	int  findroom();
}
