package _1�ӿ�һ;

public interface IFeedAble
{
	void feed(Baby b);
}
