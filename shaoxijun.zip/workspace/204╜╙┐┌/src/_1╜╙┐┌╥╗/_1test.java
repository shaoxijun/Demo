package _1�ӿ�һ;

public class _1test 
{
	public static void main(String[] args) throws InterruptedException
	{
		
	
//		Baby b = new Baby();
//		b.setHungry(0);
//		Mother m = new Mother();
//		Father f = new Father();
//		Grandmother g = new Grandmother();
//		Robot r = new Robot();
//		b.feedMan = r;
//		b.ff = f;
//		do
//		{
//			b.setHungry(b.getHungry() + 10);
//			Thread.sleep(500);
//		} while (b.alive());
		
	//��Ů����	
//		Woman w = new Woman();
//		w.name = "�����";
//		Man  m = new Man();
//		m.setName("���»�");
//		w.bf = m;
//		w.dosomething();
		
		
		//�ҷ���
//		Person p = new Person();
//		p.name = "���»�";
//		Agent a = new Agent();
//		a.name = "����";
//		Friend f = new Friend();
//		f.name = "ϰdada";
//		p.fra = a;
//		p.frf = f;
//		p.find();
		
		
		//�޿յ�
		Person p1 = new Person();
		p1.name = "С��";
		Prefession pp = new Prefession();
		pp.name = "רҵ������";
		Aircondition air = new Aircondition();
		air.setDegree(0);
		air.r1 = p1;
		air.r2 = pp;
		for(int i=0;i<=5;i++)
		{
			int a = (int)(100*Math.random());
			air.setDegree(a+1);
		}
		
		
		
	}
}
