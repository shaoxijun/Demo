package test;

public class testDemo
{
	
	public static void main(String[] args)
	{
		test_LinkedList<Integer> t = new test_LinkedList<>();
		t.add(1);
		t.add(2);
		t.add(3);
		t.add(4);
		t.add(5);
		t.add(6);
//		t.add(2,2,34,532,321);
		t.print();
	}
}
