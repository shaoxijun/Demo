package FinalTest;

public class Card
{
	String name;

	public Card(String name)
	{
		super();
		this.name = name;
	}

	public Card()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
}
