package ˫�������ο�����;

public class testDemo
{
	public static void main(String[] args)
	{
		DoubleLinkedList<Integer> dl = new DoubleLinkedList<>();
		dl.add(3);
		dl.add(4);
		dl.add(5);
		dl.add(6);
		dl.printList();
		
	}
}
