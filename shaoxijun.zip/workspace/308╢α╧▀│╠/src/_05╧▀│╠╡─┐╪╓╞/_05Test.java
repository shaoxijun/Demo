package _05�̵߳Ŀ���;

public class _05Test
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
