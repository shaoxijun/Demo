package _04ʹ��;

public class dian 
{
	int x,y;

	public dian(int x, int y)
	{
		super();
		this.x = x;
		this.y = y;
	}
	
}
