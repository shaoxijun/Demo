package _9��ϰ;

public class MarryException extends Exception
{

	public MarryException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public MarryException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MarryException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MarryException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MarryException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
