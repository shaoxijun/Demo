
public class lx2
{
	public static void main (String[] args)
	{
		int r1=5 ;
		int r2 =10;
		int r3 =15;
		 
		double p =3.1415926;
		double s2 =r2*p*r2;
		double s3 =r3*p*r3;
		double s1 =r1*p*r1;
		System.out.println("\nԲ1�����="+s1);
		System.out.println("\nԲ2�����="+s2);
		System.out.println("\nԲ3�����="+s3);
		
		
	}

}
