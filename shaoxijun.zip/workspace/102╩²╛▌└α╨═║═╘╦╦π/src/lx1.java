
public class lx1
{
	public static void main(String[] args)
	{
		int l =10;
		int k =5;
		int h =20;
		int v;
		v = l*k*h;
		System.out.println("���������="+v);
		
		
		
	}
}
