
public class lx5
{
	public static void main(String[] args)
	{
		int a=3,b=5,c=9;
		int sum=a+b+c;
		float A=3.5F,B=1.3F,C=9.2F;
		float average=(A+B+C)/3;
		System.out.println(sum);
		System.out.println(average);
		
	}
}
