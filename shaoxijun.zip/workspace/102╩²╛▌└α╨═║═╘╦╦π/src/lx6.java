
public class lx6
{
	public static void main(String[] args)
	{
		int yuwen =95,shuxue=65,waiyu=80;
		int sum,average;
		sum=(yuwen+shuxue+waiyu);
		average=(yuwen+shuxue+waiyu)/3;
		System.out.println("�ܷ֣�"+sum);
		System.out.println("ƽ���֣�"+average);
	}
}
