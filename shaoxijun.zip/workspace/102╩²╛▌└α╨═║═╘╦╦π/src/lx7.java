
public class lx7
{
	public static void main(String[] args)
	{
//		char b='b';
//		int B=(int)b;
//		B=B+13;
//		char bb;
//		bb=(char)B;
//		System.out.println(bb);
//		int s='b'+13;
//		char d=(char)s;
//		System.out.println(d);
		String l="���»�";
		String m="������";
		String n=m+l;
		System.out.println(n);
				
//		int l=40;
//		int m=100;
//		System.out.println(l+m+","+l+m);
//		
		
		
	}
}
