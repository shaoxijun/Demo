package _04;

public class Point
{

}
