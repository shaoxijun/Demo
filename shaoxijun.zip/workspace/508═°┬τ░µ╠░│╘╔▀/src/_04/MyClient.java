package _04;

public class MyClient
{

}
