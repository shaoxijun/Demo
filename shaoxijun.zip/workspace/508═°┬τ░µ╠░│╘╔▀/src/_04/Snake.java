package _04;

public class Snake
{

}
