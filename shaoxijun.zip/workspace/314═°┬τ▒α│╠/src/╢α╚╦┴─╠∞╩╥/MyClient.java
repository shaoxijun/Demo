package ����������;
import java.net.*;
import java.io.*;
public class MyClient
{
	public static void main(String[] args) throws UnknownHostException, IOException
	{
		ClientFrame cf = new ClientFrame();
		
	}

}
