package ����;
import java.net.*;
import java.util.Scanner;
import java.io.*;
public class MyServer
{
	
	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		ServerFrame sf = new ServerFrame();
			
		
	}

}
