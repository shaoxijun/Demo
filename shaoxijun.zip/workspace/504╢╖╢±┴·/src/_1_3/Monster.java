package _1_3;


public class Monster extends PlayRole
{

	public Monster(String string, int i, int j)
	{
		// TODO Auto-generated constructor stub
		this.setX(i);
		this.setY(j);
	}


}
