package _1_3;

import _1_3.Monster;

public class Princess extends PlayRole
{

	public Princess(String string, int i, int j)
	{
		// TODO Auto-generated constructor stub
		this.setX(i);
		this.setY(j);
	}
	
	
	

	

	
}
