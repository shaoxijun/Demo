package _1_3;

import _1_3.Monster;

public class Hero extends PlayRole
{

	public Hero(String name, int i, int j)
	{
		// TODO Auto-generated constructor stub
		this.setX(i);
		this.setY(j);
		this.name = name;
	}
	




	
}
